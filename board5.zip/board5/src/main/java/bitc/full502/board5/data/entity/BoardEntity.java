package bitc.full502.board5.data.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "t_jpa_bbs")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class BoardEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int boardIdx;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(nullable = false, length = 500)
    private String contents;

    @Column(nullable = false, length = 45, name = "create_id")
    private String createId;

    @Column(nullable = false)
    private LocalDateTime createDate = LocalDateTime.now();

    private  String updateId;

    private LocalDateTime updateDate;

    @Column(nullable = false)
    @ColumnDefault("0")
    private int hitCnt;

    // 참조키 설정
    @OneToMany(mappedBy = "board", cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<ReplyEntity> replyList = new ArrayList<>();

}
