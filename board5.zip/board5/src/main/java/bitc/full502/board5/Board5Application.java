package bitc.full502.board5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Board5Application {

    public static void main(String[] args) {
        SpringApplication.run(Board5Application.class, args);
    }

}
