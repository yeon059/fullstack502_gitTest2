package bitc.full502.board5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Board5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
